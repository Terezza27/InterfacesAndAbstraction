﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T04.BorderControl
{
    public interface IBirthdateable
    {
        public string Birthdate { get; set; }
    }
}
